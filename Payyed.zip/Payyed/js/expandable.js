const expandable = document.querySelector("#expandable");

expandable.addEventListener("change", () => {
    if (expandable.checked) {
        
    }
});